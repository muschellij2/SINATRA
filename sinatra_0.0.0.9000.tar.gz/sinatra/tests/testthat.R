library(testthat)
library(sinatra)

test_check("sinatra")
